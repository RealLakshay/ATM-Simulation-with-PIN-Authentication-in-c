#include <stdio.h>
#include <stdlib.h>

#define MAX_ATTEMPTS 3

int authenticate(int pin) {
    int inputPin, attempts = 0;

    while (attempts < MAX_ATTEMPTS) {
        printf("Enter PIN: ");
        scanf("%d", &inputPin);

        if (inputPin == pin) {
            return 1;
        } else {
            attempts++;
            printf("Incorrect PIN. You have %d attempt(s) left.\n", MAX_ATTEMPTS - attempts);
        }
    }

    return 0;
}

void displayMenu() {
    printf("\nATM Menu:\n");
    printf("1. Check Balance\n");
    printf("2. Deposit\n");
    printf("3. Withdraw\n");
    printf("4. Change PIN\n");
    printf("5. Exit\n");
    printf("Select an option: ");
}

void checkBalance(float balance) {
    printf("Your current balance is: $%.2f\n", balance);
}

void deposit(float *balance) {
    float depositAmount;
    printf("Enter deposit amount: $");
    scanf("%f", &depositAmount);
    *balance += depositAmount;
    printf("You have successfully deposited $%.2f. New balance: $%.2f\n", depositAmount, *balance);
}

void withdraw(float *balance) {
    float withdrawAmount;
    printf("Enter withdrawal amount: $");
    scanf("%f", &withdrawAmount);

    if (withdrawAmount > *balance) {
        printf("Insufficient funds! Your balance is $%.2f.\n", *balance);
    } else {
        *balance -= withdrawAmount;
        printf("You have successfully withdrawn $%.2f. New balance: $%.2f\n", withdrawAmount, *balance);
    }
}

void changePin(int *pin) {
    int oldPin, newPin;
    printf("Enter old PIN: ");
    scanf("%d", &oldPin);

    if (oldPin == *pin) {
        printf("Enter new PIN: ");
        scanf("%d", &newPin);
        *pin = newPin;
        printf("Your PIN has been successfully changed.\n");
    } else {
        printf("Incorrect old PIN. PIN change failed.\n");
    }
}

int main() {
    int pin = 1234;
    float balance = 1000.0;
    int choice;

    if (!authenticate(pin)) {
        printf("Too many incorrect attempts. Exiting...\n");
        return 0;
    }

    while (1) {
        displayMenu();
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                checkBalance(balance);
                break;
            case 2:
                deposit(&balance);
                break;
            case 3:
                withdraw(&balance);
                break;
            case 4:
                changePin(&pin);
                break;
            case 5:
                printf("Thank you for using the ATM. Goodbye!\n");
                exit(0);
            default:
                printf("Invalid option. Please try again.\n");
        }
    }

    return 0;
}
